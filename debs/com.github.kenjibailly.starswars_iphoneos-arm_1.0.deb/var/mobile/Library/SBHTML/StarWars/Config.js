var size = "0.5"; 
