var rotate = 65; // Choose degrees
var size = 0.8; // Choose between 0.1 and 5
var cup = true; // Set to true or false
