var color = "green"; // Set color with name or hex
var size = 0.2; // Choose between 0 and 1
var move = true; 
var speed = 6; 
var rotate = "63"; 
